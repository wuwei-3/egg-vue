// This file is created by egg-ts-helper@1.29.1
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportAdmin = require('../../../app/controller/admin');
import ExportFile = require('../../../app/controller/file');
import ExportHome = require('../../../app/controller/home');
import ExportNews = require('../../../app/controller/news');
import ExportPhone = require('../../../app/controller/phone');

declare module 'egg' {
  interface IController {
    admin: ExportAdmin;
    file: ExportFile;
    home: ExportHome;
    news: ExportNews;
    phone: ExportPhone;
  }
}
